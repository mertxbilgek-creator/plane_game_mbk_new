"""
Sky Escape - A simple side-scrolling airplane game made with Pygame.

Controls:
    UP / DOWN    Fly the plane
    P / ESC      Pause
    M            Toggle music
    L            Change language (English / Turkish)
    F11          Toggle fullscreen
"""

import pygame
import random
import sys
import os
import json
import math
from array import array
from datetime import datetime

# ---------------- Settings ----------------
WIDTH, HEIGHT = 800, 500
FPS = 60

WHITE = (255, 255, 255)
SKY = (120, 190, 255)
GREEN = (60, 170, 80)
DARK_GREEN = (40, 120, 55)
RED = (220, 50, 50)
YELLOW = (255, 210, 60)
NAVY = (25, 45, 110)
LIGHT_NAVY = (50, 80, 170)
GRAY = (150, 155, 165)
DARK_GRAY = (90, 95, 105)
GLASS = (40, 60, 90)
CLOUD = (235, 245, 255)
SHADOW = (20, 30, 70)

MUSIC_VOLUME = 0.4

try:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:
    BASE_DIR = os.getcwd()
SCORES_FILE = os.path.join(BASE_DIR, "scores.json")
SETTINGS_FILE = os.path.join(BASE_DIR, "settings.json")

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.SCALED | pygame.FULLSCREEN)
clock = pygame.time.Clock()
small_font = pygame.font.SysFont("arial", 16)
medium_font = pygame.font.SysFont("arial", 22)
font = pygame.font.SysFont("arial", 26, bold=True)
big_font = pygame.font.SysFont("arial", 52, bold=True)
title_font = pygame.font.SysFont("arial", 64, bold=True)


# ---------------- Localization ----------------
TEXTS = {
    "en": {
        "title": "SKY ESCAPE",
        "start": "Start Game",
        "scores": "Scores",
        "language_btn": "Language: English",
        "quit": "Quit",
        "high_score": "High Score: {}",
        "menu_hint": "F11: Fullscreen  |  M: Sound  |  L: Language",
        "scores_title": "SCORES",
        "top_scores": "Top Scores",
        "recent_games": "Recent Games",
        "no_scores": "No scores yet, let's fly!",
        "points": "{} pts",
        "back": "Back",
        "score": "Score: {}",
        "pause_hint": "P / ESC: Pause",
        "paused": "PAUSED",
        "resume": "Resume",
        "restart": "Restart",
        "main_menu": "Main Menu",
        "crashed": "YOU CRASHED!",
        "your_score": "Your Score: {}",
        "new_record": "NEW RECORD!",
        "record": "Record: {}",
        "play_again": "Play Again",
        "skip": "Press ENTER to skip",
        "percent": "{}%",
        "loading": [
            "Warming up engines...",
            "Refueling...",
            "Placing clouds...",
            "Loading scores...",
            "Ready for takeoff!",
        ],
    },
    "tr": {
        "title": "GÖKYÜZÜ KAÇIŞI",
        "start": "Oyuna Başla",
        "scores": "Skorlar",
        "language_btn": "Dil: Türkçe",
        "quit": "Çıkış",
        "high_score": "En Yüksek Skor: {}",
        "menu_hint": "F11: Tam ekran  |  M: Ses  |  L: Dil",
        "scores_title": "SKORLAR",
        "top_scores": "En Yüksek Skorlar",
        "recent_games": "Son Oyunlar",
        "no_scores": "Henüz skor yok, hadi uçmaya!",
        "points": "{} puan",
        "back": "Geri",
        "score": "Puan: {}",
        "pause_hint": "P / ESC: Duraklat",
        "paused": "DURAKLATILDI",
        "resume": "Devam Et",
        "restart": "Yeniden Başla",
        "main_menu": "Ana Menü",
        "crashed": "ÇARPTIN!",
        "your_score": "Puanın: {}",
        "new_record": "YENİ REKOR!",
        "record": "Rekor: {}",
        "play_again": "Tekrar Oyna",
        "skip": "Atlamak için ENTER",
        "percent": "%{}",
        "loading": [
            "Motorlar ısıtılıyor...",
            "Yakıt dolduruluyor...",
            "Bulutlar yerleştiriliyor...",
            "Skorlar yükleniyor...",
            "Kalkışa hazır!",
        ],
    },
}
DEFAULT_LANGUAGE = "en"


def load_settings():
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def save_settings():
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump({"language": language}, f)
    except OSError:
        pass


language = load_settings().get("language", DEFAULT_LANGUAGE)
if language not in TEXTS:
    language = DEFAULT_LANGUAGE


def t(key, *values):
    """Return the text for the given key in the current language."""
    text = TEXTS[language][key]
    return text.format(*values) if values else text


def toggle_language():
    global language
    language = "tr" if language == "en" else "en"
    pygame.display.set_caption(t("title"))
    save_settings()


pygame.display.set_caption(t("title"))


# ---------------- Scores ----------------
def load_scores():
    try:
        with open(SCORES_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def save_score(score):
    scores = load_scores()
    scores.append({"score": score, "date": datetime.now().strftime("%Y-%m-%d %H:%M")})
    scores = scores[-50:]  # Keep only the last 50 games
    try:
        with open(SCORES_FILE, "w", encoding="utf-8") as f:
            json.dump(scores, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


def best_score():
    return max((s.get("score", 0) for s in load_scores()), default=0)


# ---------------- Helpers ----------------
def draw_text(text, f, color, x, y):
    surface = f.render(text, True, color)
    screen.blit(surface, surface.get_rect(center=(x, y)))


def draw_shadow_text(text, f, color, x, y):
    draw_text(text, f, SHADOW, x + 3, y + 3)
    draw_text(text, f, color, x, y)


def draw_top_right(text):
    surface = small_font.render(text, True, WHITE)
    screen.blit(surface, (WIDTH - surface.get_width() - 12, 15))


def create_music():
    """Generate a short looping melody in code, so no audio file is needed."""
    mixer_info = pygame.mixer.get_init()
    if mixer_info is None:
        return None  # No audio device, play without music
    sample_rate, _, channels = mixer_info

    notes = {
        "F2": 87.31, "G2": 98.00, "A2": 110.00, "C3": 130.81,
        "F4": 349.23, "G4": 392.00, "A4": 440.00, "B4": 493.88,
        "C5": 523.25, "D5": 587.33, "E5": 659.25, "-": 0,
    }
    melody = [
        "C5", "E5", "G4", "E5", "A4", "C5", "E5", "D5",
        "C5", "G4", "A4", "B4", "C5", "-", "G4", "-",
        "F4", "A4", "C5", "A4", "G4", "B4", "D5", "B4",
        "C5", "E5", "D5", "B4", "C5", "-", "-", "-",
    ]
    bass = ["C3", "A2", "F2", "G2"]  # Changes every 8 notes

    note_length = 0.2
    n = int(sample_rate * note_length)
    bar_length = n * 8
    data = array("h")

    for i, note in enumerate(melody):
        freq = notes[note]
        bass_freq = notes[bass[i // 8]]
        for s in range(n):
            time_s = s / sample_rate
            # Soft attack at the start of the note, fade out at the end
            envelope = min(1, s / 200) * (1 - s / n)
            value = 0
            if freq:
                value += math.sin(2 * math.pi * freq * time_s) * 0.5 * envelope
                value += math.sin(4 * math.pi * freq * time_s) * 0.15 * envelope

            # Bass with smooth transitions at bar boundaries
            bar_pos = (i % 8) * n + s
            bass_env = min(1, bar_pos / 400) * min(1, (bar_length - bar_pos) / 400)
            value += math.sin(2 * math.pi * bass_freq * bar_pos / sample_rate) * 0.25 * bass_env

            sample = int(value * 6000)
            data.append(sample)
            if channels == 2:
                data.append(sample)

    return pygame.mixer.Sound(buffer=data.tobytes())


music = None


def handle_common_events(event):
    if event.type == pygame.QUIT:
        pygame.quit()
        sys.exit()
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_F11:
            pygame.display.toggle_fullscreen()
        if event.key == pygame.K_m and music:
            music.set_volume(0 if music.get_volume() > 0 else MUSIC_VOLUME)
        if event.key == pygame.K_l:
            toggle_language()


class Button:
    def __init__(self, text_key, x, y, width=280, height=50):
        self.text_key = text_key  # Text is read from the current language every frame
        self.rect = pygame.Rect(0, 0, width, height)
        self.rect.center = (x, y)

    def draw(self, surface):
        hovered = self.rect.collidepoint(pygame.mouse.get_pos())
        color = LIGHT_NAVY if hovered else NAVY
        pygame.draw.rect(surface, color, self.rect, border_radius=12)
        pygame.draw.rect(surface, YELLOW if hovered else WHITE, self.rect, 3, border_radius=12)
        label = font.render(t(self.text_key), True, WHITE)
        surface.blit(label, label.get_rect(center=self.rect.center))

    def clicked(self, event):
        return (event.type == pygame.MOUSEBUTTONDOWN and event.button == 1
                and self.rect.collidepoint(event.pos))


# ---------------- Game objects ----------------
class Plane:
    def __init__(self):
        self.x = 140
        self.y = HEIGHT // 2
        self.max_speed = 5
        self.vertical_speed = 0
        self.angle = 0

    def move(self, keys):
        target = 0
        if keys[pygame.K_UP]:
            target = -self.max_speed
        if keys[pygame.K_DOWN]:
            target = self.max_speed

        # Speed changes gradually, not instantly
        self.vertical_speed += (target - self.vertical_speed) * 0.12
        self.y += self.vertical_speed

        # Screen limits
        if self.y < 35:
            self.y = 35
            self.vertical_speed = 0
        if self.y > HEIGHT - 25:
            self.y = HEIGHT - 25
            self.vertical_speed = 0

        # Nose up when climbing, nose down when descending
        self.angle = -self.vertical_speed * 3.5

    def rect(self):
        return pygame.Rect(self.x - 50, self.y - 14, 100, 26)

    def draw(self, surface):
        # Draw on a transparent surface first, then rotate it
        body = pygame.Surface((140, 90), pygame.SRCALPHA)
        x, y = 70, 45

        # Tail fin
        pygame.draw.polygon(body, NAVY, [(x - 46, y - 6), (x - 60, y - 32), (x - 46, y - 32), (x - 28, y - 6)])
        pygame.draw.line(body, YELLOW, (x - 55, y - 26), (x - 40, y - 10), 3)
        # Horizontal stabilizer
        pygame.draw.polygon(body, GRAY, [(x - 42, y + 2), (x - 58, y + 9), (x - 36, y + 6)])
        # Fuselage and nose
        pygame.draw.rect(body, WHITE, (x - 50, y - 10, 90, 20), border_radius=10)
        pygame.draw.ellipse(body, WHITE, (x + 26, y - 10, 28, 20))
        # Belly stripe
        pygame.draw.rect(body, NAVY, (x - 46, y + 3, 92, 4), border_radius=2)
        # Passenger windows
        for i in range(10):
            pygame.draw.circle(body, GLASS, (x - 34 + i * 7, y - 3), 2)
        # Cockpit window
        pygame.draw.polygon(body, GLASS, [(x + 40, y - 7), (x + 48, y - 7), (x + 45, y - 2), (x + 38, y - 2)])
        # Wing
        wing = [(x + 8, y + 2), (x - 18, y + 24), (x - 6, y + 24), (x + 20, y + 2)]
        pygame.draw.polygon(body, GRAY, wing)
        pygame.draw.polygon(body, DARK_GRAY, wing, 1)
        # Engine
        pygame.draw.ellipse(body, DARK_GRAY, (x - 4, y + 12, 20, 9))
        pygame.draw.ellipse(body, GRAY, (x + 12, y + 13, 5, 7))

        rotated = pygame.transform.rotate(body, self.angle)
        surface.blit(rotated, rotated.get_rect(center=(int(self.x), int(self.y))))


class Obstacle:
    def __init__(self, x, gap):
        self.x = x
        self.width = 70
        self.gap = gap
        self.top_height = random.randint(50, HEIGHT - gap - 50)
        self.passed = False

    def update(self, speed):
        self.x -= speed

    def rects(self):
        top = pygame.Rect(self.x, 0, self.width, self.top_height)
        bottom_y = self.top_height + self.gap
        bottom = pygame.Rect(self.x, bottom_y, self.width, HEIGHT - bottom_y)
        return top, bottom

    def draw(self, surface):
        for r in self.rects():
            pygame.draw.rect(surface, GREEN, r)
            pygame.draw.rect(surface, DARK_GREEN, r, 4)


class Cloud:
    def __init__(self, x=None):
        self.x = x if x is not None else WIDTH + random.randint(0, 200)
        self.y = random.randint(20, HEIGHT - 60)
        self.speed = random.uniform(0.5, 1.5)

    def update(self):
        self.x -= self.speed
        if self.x < -100:
            self.__init__()

    def draw(self, surface):
        x, y = int(self.x), self.y
        for dx, dy, r in [(0, 0, 18), (20, -8, 22), (42, 0, 18)]:
            pygame.draw.circle(surface, CLOUD, (x + dx, y + dy), r)


clouds = [Cloud(random.randint(0, WIDTH)) for _ in range(6)]


def draw_background(animate=True):
    screen.fill(SKY)
    for c in clouds:
        if animate:
            c.update()
        c.draw(screen)


def dim_screen(alpha=140):
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, alpha))
    screen.blit(overlay, (0, 0))


# ---------------- Screens ----------------
def loading_screen(duration=2500):
    plane = Plane()
    bar_x, bar_y, bar_w, bar_h = 150, 300, 500, 22
    start_time = pygame.time.get_ticks()

    while True:
        clock.tick(FPS)
        for event in pygame.event.get():
            handle_common_events(event)
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE):
                return

        elapsed = pygame.time.get_ticks() - start_time
        progress = min(elapsed / duration, 1)
        progress = progress * progress * (3 - 2 * progress)  # Ease in/out

        draw_background()
        dim_screen(90)
        draw_shadow_text(t("title"), title_font, WHITE, WIDTH // 2, 140)

        # Progress bar
        pygame.draw.rect(screen, NAVY, (bar_x, bar_y, bar_w, bar_h), border_radius=11)
        filled = int(bar_w * progress)
        if filled > 0:
            pygame.draw.rect(screen, YELLOW, (bar_x, bar_y, filled, bar_h), border_radius=11)
        pygame.draw.rect(screen, WHITE, (bar_x, bar_y, bar_w, bar_h), 3, border_radius=11)

        # Plane flying along the bar
        plane.x = bar_x + filled
        plane.y = bar_y - 30
        plane.angle = math.sin(elapsed / 150) * 4
        plane.draw(screen)

        draw_text(t("percent", int(progress * 100)), font, WHITE, bar_x + bar_w + 45, bar_y + bar_h // 2)

        messages = t("loading")
        message = messages[min(int(progress * len(messages)), len(messages) - 1)]
        draw_text(message, medium_font, WHITE, WIDTH // 2, 360)
        draw_text(t("skip"), small_font, WHITE, WIDTH // 2, HEIGHT - 20)

        pygame.display.flip()

        if elapsed >= duration:
            pygame.time.wait(300)
            return


def main_menu():
    plane = Plane()
    plane.x = WIDTH // 2
    start_btn = Button("start", WIDTH // 2, 225)
    scores_btn = Button("scores", WIDTH // 2, 285)
    language_btn = Button("language_btn", WIDTH // 2, 345)
    quit_btn = Button("quit", WIDTH // 2, 405)
    record = best_score()

    while True:
        clock.tick(FPS)
        for event in pygame.event.get():
            handle_common_events(event)
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    return "game"
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
            if start_btn.clicked(event):
                return "game"
            if scores_btn.clicked(event):
                return "scores"
            if language_btn.clicked(event):
                toggle_language()
            if quit_btn.clicked(event):
                pygame.quit()
                sys.exit()

        draw_background()

        # Plane gently floating in the menu
        time_s = pygame.time.get_ticks() / 500
        plane.y = 145 + math.sin(time_s) * 8
        plane.angle = math.cos(time_s) * 6
        plane.draw(screen)

        draw_shadow_text(t("title"), title_font, WHITE, WIDTH // 2, 65)
        start_btn.draw(screen)
        scores_btn.draw(screen)
        language_btn.draw(screen)
        quit_btn.draw(screen)
        draw_shadow_text(t("high_score", record), medium_font, YELLOW, WIDTH // 2, 463)
        draw_top_right(t("menu_hint"))

        pygame.display.flip()


def scores_screen():
    back_btn = Button("back", WIDTH // 2, 445, 200)
    scores = load_scores()
    top = sorted(scores, key=lambda s: s.get("score", 0), reverse=True)[:5]
    recent = list(reversed(scores))[:5]

    while True:
        clock.tick(FPS)
        for event in pygame.event.get():
            handle_common_events(event)
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
                return "menu"
            if back_btn.clicked(event):
                return "menu"

        draw_background()
        dim_screen(110)
        draw_shadow_text(t("scores_title"), big_font, WHITE, WIDTH // 2, 55)

        left_x, right_x = WIDTH // 4 + 20, WIDTH * 3 // 4 - 20
        draw_text(t("top_scores"), font, YELLOW, left_x, 125)
        draw_text(t("recent_games"), font, YELLOW, right_x, 125)

        if not scores:
            draw_text(t("no_scores"), medium_font, WHITE, WIDTH // 2, 250)
        else:
            for i, s in enumerate(top):
                line = f"{i + 1}.  {t('points', s.get('score', 0))}  -  {s.get('date', '')}"
                draw_text(line, medium_font, WHITE, left_x, 175 + i * 40)
            for i, s in enumerate(recent):
                line = f"{t('points', s.get('score', 0))}  -  {s.get('date', '')}"
                draw_text(line, medium_font, WHITE, right_x, 175 + i * 40)

        back_btn.draw(screen)
        pygame.display.flip()


def game():
    plane = Plane()
    obstacles = []
    score = 0
    obstacle_speed = 4
    gap = 190
    spawn_timer = 0
    state = "playing"  # "playing", "paused", "over"
    previous_record = best_score()
    new_record = False

    # Pause menu buttons
    resume_btn = Button("resume", WIDTH // 2, 220)
    restart_btn = Button("restart", WIDTH // 2, 285)
    menu_btn = Button("main_menu", WIDTH // 2, 350)

    # Game over buttons
    again_btn = Button("play_again", WIDTH // 2, 330)
    over_menu_btn = Button("main_menu", WIDTH // 2, 395)

    while True:
        clock.tick(FPS)

        for event in pygame.event.get():
            handle_common_events(event)

            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_ESCAPE, pygame.K_p):
                    if state == "playing":
                        state = "paused"
                    elif state == "paused":
                        state = "playing"
                    elif state == "over" and event.key == pygame.K_ESCAPE:
                        return "menu"
                if state == "over" and event.key == pygame.K_r:
                    return "game"

            if state == "paused":
                if resume_btn.clicked(event):
                    state = "playing"
                elif restart_btn.clicked(event):
                    return "game"
                elif menu_btn.clicked(event):
                    return "menu"
            elif state == "over":
                if again_btn.clicked(event):
                    return "game"
                elif over_menu_btn.clicked(event):
                    return "menu"

        # --- Update (only while playing) ---
        if state == "playing":
            plane.move(pygame.key.get_pressed())

            spawn_timer += 1
            if spawn_timer >= 90:
                obstacles.append(Obstacle(WIDTH, gap))
                spawn_timer = 0

            for o in obstacles[:]:
                o.update(obstacle_speed)

                for r in o.rects():
                    if plane.rect().colliderect(r):
                        state = "over"

                if not o.passed and o.x + o.width < plane.x:
                    o.passed = True
                    score += 1
                    # Every 5 points the game gets harder
                    if score % 5 == 0:
                        obstacle_speed += 0.5
                        gap = max(130, gap - 10)

                if o.x + o.width < 0:
                    obstacles.remove(o)

            # Save the score once when the plane crashes
            if state == "over":
                save_score(score)
                new_record = score > previous_record and score > 0

        # --- Draw ---
        draw_background(animate=(state == "playing"))
        for o in obstacles:
            o.draw(screen)
        plane.draw(screen)

        screen.blit(font.render(t("score", score), True, WHITE), (15, 10))
        draw_top_right(t("pause_hint"))

        if state == "paused":
            dim_screen()
            draw_shadow_text(t("paused"), big_font, WHITE, WIDTH // 2, 130)
            resume_btn.draw(screen)
            restart_btn.draw(screen)
            menu_btn.draw(screen)
        elif state == "over":
            dim_screen()
            draw_shadow_text(t("crashed"), big_font, RED, WIDTH // 2, 140)
            draw_text(t("your_score", score), font, WHITE, WIDTH // 2, 205)
            if new_record:
                draw_text(t("new_record"), font, YELLOW, WIDTH // 2, 250)
            else:
                draw_text(t("record", previous_record), medium_font, YELLOW, WIDTH // 2, 250)
            again_btn.draw(screen)
            over_menu_btn.draw(screen)

        pygame.display.flip()


# ---------------- Main ----------------
def main():
    global music
    try:
        music = create_music()
    except Exception:
        music = None

    if music:
        music.set_volume(MUSIC_VOLUME)
        music.play(loops=-1)

    loading_screen()
    state = "menu"
    while True:
        if state == "menu":
            state = main_menu()
        elif state == "scores":
            state = scores_screen()
        elif state == "game":
            state = game()


if __name__ == "__main__":
    main()